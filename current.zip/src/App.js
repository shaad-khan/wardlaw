import React,{Component} from 'react';
import logo from './logo.svg';
import './App.css';
import { Layout,Card } from 'antd';
import { Row, Col,Form, Input, Button, Checkbox } from 'antd';
const { Header, Footer, Sider, Content } = Layout;
const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
class App extends Component {
  constructor(props) {
		super(props);
    this.state = {
      collapsed: false,
    };
  }
  
  render()
  {
  return (
    <div className="App">
    
 
    <Layout className="site-layout">
      <Content>
        
      <div className="site-card-border-less-wrapper" style={{height: "1000px"}}>
  
    <Card title="" bordered={false} style={{ width: "69%",marginLeft: "16%",marginTop: "13%" }}>
    <Row>
      <Col span={12}>
         <div>
        <img src="https://www.wardlawclaims.com/wp-content/uploads/wardlaw_claims_logo_dark_2x.png"/>
        </div>
      </Col>
      <Col span={12}> 
      <div style={{marginTop: "5%"}}>
      <Form
      {...layout}
      name="basic"
      initialValues={{ remember: true }}
     
    >
      <Form.Item
        label="Username"
        name="username"
        rules={[{ required: true, message: 'Please input your username!' }]}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Password"
        name="password"
        rules={[{ required: true, message: 'Please input your password!' }]}
      >
        <Input.Password />
      </Form.Item>

     

      <Form.Item {...tailLayout}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
        <Button type="danger" htmlType="submit" style={{marginLeft:"2%"}}>
          Google Signin
        </Button>
      </Form.Item>
    </Form>
    
    </div>
    </Col>
    </Row>
      
    </Card>
  </div>


      </Content>
    
    </Layout>

    
  </div>
 
); 
}
}

export default App;
