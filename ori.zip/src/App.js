import React,{Component} from 'react';
import logo from './logo.svg';
import './App.css';
import Amplify,{Auth} from 'aws-amplify';
import awsconfig from './aws-exports';
//import { withAuthenticator } from 'aws-amplify-react'; // or 'aws-amplify-react-native';
import 'bootstrap/dist/css/bootstrap.min.css';
import {nav,Navbar} from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import Routes from './Routes';
Amplify.configure(awsconfig);

class App extends Component {
	constructor(props) {
		super(props);

		this.state = {
			isAuthenticated: false,
      isAuthenticating: true,
      Userinfo:'',
      Group:'',

      
		};
	}

	async componentDidMount() {
  
		try {
			if (await Auth.currentSession()) {
        this.userHasAuthenticated(true);
        var data=await Auth.currentUserInfo()
        this.setState({ Userinfo: data });
        const user =  await Auth.currentAuthenticatedUser();
        this.setGroupinfo(user.signInUserSession.accessToken.payload["cognito:groups"][0]);
        //location.reload()
			}
		} catch (e) {
			if (e !== 'No current user') {
				alert(e);
			}
		}

		this.setState({ isAuthenticating: false });
	}

	userHasAuthenticated = authenticated => {
  
		this.setState({ isAuthenticated: authenticated });
  };
  setUserinfo = (data) => {
    console.log(data)
		this.setState({ Userinfo: data });
  };
  setGroupinfo = (data) => {
  console.log(data)
		this.setState({ Group: data });
	};

	handleLogout = async event => {
		await Auth.signOut();

		this.userHasAuthenticated(false);
		this.props.history.push('/login');
	};
	render() {
		const childProps = {
			isAuthenticated: this.state.isAuthenticated,
      userHasAuthenticated: this.userHasAuthenticated,
    
      Group:this.state.Group,
      Userinfo:this.state.Userinfo,
      isAuthenticating:this.state.isAuthenticating,
      setUserinfo:this.setUserinfo,
      setGroupinfo:this.setGroupinfo
    
		};
  return (
    <div className="App">
  
  <Navbar bg="dark" variant="dark">
    <Navbar.Brand href="/">
      <img
        alt=""
        src="/logo.svg"
        width="30"
        height="30"
        className="d-inline-block align-top"
      />{' '}
      WardLaw
    </Navbar.Brand>
    <Navbar.Collapse className="justify-content-end">
    <Navbar.Text>
      <button ><a href="/login">Login</a></button>
    </Navbar.Text>
    <Navbar.Text>
      <button >signup</button>
    </Navbar.Text>
  </Navbar.Collapse>
  </Navbar>
  <Routes childProps={childProps} />
    </div>
  );
  }
}

export default App;
