import React, { Component } from 'react';

import { API } from 'aws-amplify';
import './Home.css';

export default class Home extends Component {
	constructor(props) {
		super(props);

		this.state = {
			isLoading: true,
			testApiCall: [],
			

			
		};
	}

	
	renderLander() {
		return (
			<div className="lander">
				<h1>Test web app</h1>
				<p> Wardlaw Digital Portal React test app</p>
			</div>
		);
	}

	renderTest() {
		return (
			<div >
				<h1>Hi here  {JSON.stringify(this.props)} {JSON.stringify(this.props.Userinfo)}</h1>
				<p>user belongs to GROUP : {this.props.Group}</p>
			</div>
		);
	}

	render() {
		return <div className="Home"> {this.props.isAuthenticated ? this.renderTest() : this.renderLander()}</div>;
	}
}
