import React, { Component } from 'react';
import { FormGroup, FormControl, p } from 'react-bootstrap';

import { Auth } from 'aws-amplify';

import './Login.css';

export default class Login extends Component {
	constructor(props) {
		super(props);

		this.state = {
			isLoading: false,
			email: '',
			password: '',
			


		};
	}

	validateForm() {
		return this.state.email.length > 0 && this.state.password.length > 0;
	}

	handleChange = event => {
		this.setState({
			[event.target.id]: event.target.value
		});
	};
	federatedlogin=async event => {
		await Auth.federatedSignIn({provider:"Google"});
		
        //this.setState({Group:user.signInUserSession.accessToken.payload["cognito:groups"][0]})
		this.props.history.push('/home');
	}
	handleSubmit = async event => {
		event.preventDefault();

		this.setState({ isLoading: true });

		try {
			await Auth.signIn(this.state.email, this.state.password);
			//this.props.userHasAuthenticated(true);
			
				//alert('redirecting to home')
				this.props.history.push('/home');
				
			
			
		} catch (e) {
			alert(e.message);
			this.setState({ isLoading: false });
		}
	};

	render() {
		return (
			<div className="login-form">
    <form onSubmit={this.handleSubmit}>		
        <div className="text-center social-btn">
            
			<a href="#" className="btn btn-danger btn-lg btn-block" onClick={this.federatedlogin}><i className="fa fa-google"></i> Sign in with <b>Google</b></a>
        </div>
		<div className="or-seperator"><b>or</b></div>
        <div className="form-group">
        	<input type="text" id="email" value={this.state.email} onChange={this.handleChange} className="form-control input-lg" name="username" placeholder="Username" required="required"/>
        </div>
		<div className="form-group">
            <input type="password" id="password" value={this.state.password} onChange={this.handleChange} className="form-control input-lg" name="password" placeholder="Password" required="required"/>
        </div>        
        <div className="form-group">
            <button type="submit" className="btn btn-success btn-lg btn-block login-btn" disabled={!this.validateForm()}>Sign in</button>
        </div>
    </form>
   
</div>
		);
	}
}
