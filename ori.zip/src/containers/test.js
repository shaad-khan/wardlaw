import React from 'react';
import './NotFound.css';

export default (props) => (
	<div className="NotFound">
		<h3>Sorry, page not found!</h3>
	</div>
);
