import React, { Component, Fragment } from 'react';
import logo from './logo.svg';
import './App.css';
import { Layout, Menu,Dropdown } from 'antd';
import { Button } from 'antd';
import {  Breadcrumb } from 'antd';
const { Header, Footer, Sider, Content } = Layout;
export default class Dashboard extends Component {
    constructor(props) {
          super(props);
      this.state = {
        collapsed: false,
      };
    }
render()
{
    return(
        <Content style={{ margin: '0 16px' }}>
        <Breadcrumb style={{ margin: '16px 0' }}>
         
          <Breadcrumb.Item>Dashboard</Breadcrumb.Item>
        </Breadcrumb>
        <div className="site-layout-background" style={{ padding: 24, minHeight: 360 }}>
              Bill is a cat.
            </div>
        </Content>
    )
}
}