import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import logo from './logo.svg';
import './App.css';
import { Layout, Menu,Dropdown } from 'antd';
import Dashboard from "./dashboard"
import { Button } from 'antd';
import {  Breadcrumb } from 'antd';
import { Avatar } from 'antd';
import { UsrOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,user,
  UserOutlined,LogoutOutlined,
  VideoCameraOutlined,ProfileOutlined,SettingOutlined,RedoOutlined,HourglassOutlined,
  UploadOutlined,HomeOutlined,FieldTimeOutlined,LineChartOutlined,FileSyncOutlined
} from '@ant-design/icons';
import {
  DesktopOutlined,
  PieChartOutlined,
  FileOutlined,
  TeamOutlined,
 
} from '@ant-design/icons';

const { Header, Footer, Sider, Content } = Layout;
const { SubMenu } = Menu;
const menu = (
  <Menu>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer" href="http://www.alipay.com/">
      <SettingOutlined /> Setting
      </a>
    </Menu.Item>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer" href="http://www.taobao.com/">
      <ProfileOutlined /> profile
      </a>
    </Menu.Item>
    <Menu.Item>
      <a target="_blank" rel="noopener noreferrer" href="http://www.tmall.com/">
      <LogoutOutlined /> Logout
      </a>
    </Menu.Item>
  </Menu>
);
class App extends Component {
  constructor(props) {
		super(props);
    this.state = {
      collapsed: false,
    };
  }
    onCollapse = collapsed => {
      console.log(collapsed);
      this.setState({ collapsed });
    };

  render() {
    return (
      <Router>
      <Layout style={{ minHeight: '100vh' }}>
        

       
      <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
      {!this.state.collapsed?( <div class="logo" id="cust"><img src="https://www.wardlawclaims.com/wp-content/uploads/wardlaw_claims_logo_dark_2x.png"
    width="112px"/></div>):<div class="logo" id="cust2"></div>}
       
        
        <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline">
          <Menu.Item key="1">
          <HomeOutlined />
            <span><Link to="/" style={{textDecoration:"none",color:"#fff"}}>Dashboard</Link></span>
          </Menu.Item>
          <Menu.Item key="2">
          <RedoOutlined />
            <span>Onboarding</span>
          </Menu.Item>
          <Menu.Item key="3">
          <HourglassOutlined />
            <span>CAT Notification</span>
          </Menu.Item>
          <Menu.Item key="4">
          <FieldTimeOutlined />
            <span>FNOL</span>
          </Menu.Item>
          <Menu.Item key="5">
          <FileSyncOutlined />
            <span>Renewals</span>
          </Menu.Item>
          <Menu.Item key="6">
          <LineChartOutlined />
            <span>Analytics</span>
          </Menu.Item>
         
        </Menu>
      </Sider>
      <Layout className="site-layout">
        <Header className="site-layout-background" style={{ padding: 0 }} > 
        
        <div><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIYAAACFCAMAAACpM3ANAAAA/1BMVEX////rHiViYmIBvPEAfLhaWlpdXV1XV1dxqMlTU1MAd7b19fWXl5ez0jb8/Pzm5ubExMRra2tOTk52dnadnZ27u7vQ0NCvr6/W1tbe3t6jo6NISEjKyspwcHDu7u6CgoKLi4vnAAAFqN7sFR3rCBQAtOvs+fkAdroDicMCmtH66+vkl5noi4711NX24uPlXWDvurvzycrjQkTiUFHndXbtrK3kLzLhNjjifH3roqXkJSqK1O7lZWh20OvT7vdWx+w1w/Ch3fLaAA/l7sf1+Oq75/Wtzxu71F3Q4pLR4Zvc6LOdx0FipXobgavC2Wxfo4G51U21z7V0rLlputs6Ojq0wrqSAAAKpElEQVR4nO2beXfTSBLA7U66e4VMy5Is67Auj50wBAjXMBAgzO6EzcCyw8we3/+zbFV16/CVxImPt++l/gCd3T/V2V2GTufOcvLk7mNsQJ6On+0bAeR0Mn2+bwaQj9Pu+MW+ITovx93u5NXJninU60m32x3v20vPQBkgk9O9Upx0J4Qx/WmvGO+mXS17DdrTsaHoTl6rvVGo55MKozt+szeMF7UyQB0/23uiUG8bZYCXPt0TxpOWMtAs+8lhJ7MU+wraOlhrdbzcA8XLOWWAl77dfdDqYjJnlrOdY7yYNwmZZdfqUAsmIXW82zHGk6UY3eluS8vJMpMgxm7Xg89XYHSnu1wPLvVPkkl3hxhvF4O1DpbdBe2b5f6p5dddrQdP3l9B0R3vqrQ8vUIZk+n0592o49kq/5xMx+PnZ7vKHEuKCTKMp6/evdjdkmOxskK2mHZfnz2rV4HH2y8taj5YJ+Nx92lbDccfjj5sHWO2mEzH3Y9nMy55fH5wdHDwacsUp+9bapi8fffydMYAGuLg4JctY3yc1kHx6uzZnA8cf9AQBwdH21XHs7H2hlfvXi644fG5YUD56/EWKdTr6XT8/vmT08XABHO05ehvW8R4M/71pxfLkiSYY062qA71ZnmKhBA9msc42raXzsunBU3swkvnpImOedmWOi4+L1z6dL5ojlodf98OxeWfv325+NwK1E/nqxC256Xqt4cglw+/f73QJOp8lTkqdWyjtPzj8qGWy8vL718uZpLVKo7Ne+nnhy25/PbPw8PHP1wLcr5xjK8tim9//P7oEOXHxz/sVh2fL9uaePTg0MiDq1F+2ewCSH1vNHH46HBeflxloA2Xlot5cyzKcpTNBu2f2hyrIVYZaKNB+/VylTmu1coGvfTz1ea4GmVzQfsFouP3JjpuIo2BNlZaLr798eDRg9vI4ePHUPo2hPGvf//lLvKfnS487uVe7uVe7uVealHqDutXFSebYHCCXuEX5SC43W/LIffY3SHy0uIChXNZ3gakJ5h7Zwonk4wJKSUXjHHnxu+pPMw3iFFwJrwyCIJBNpI3Hy7OrP86m8NIJROZGc9Oihu/15fM2yBGyJkV1Wc3d42UbxSjBza5jV9uGCMBbSzzSzuO4rw6UU1a0UeKMHJ9YjAUvNFKPsqJomZg874T1ykKJmjN2wdtLIZpXLoMAqfo6zH8zA31DcfPWAp+nbkQXlmWFbbByJMM3nCDatoQTgXzzXniukPQoA8P2kUGvhj3cAJ/WE2YMwhTP+rMSGABHIwCIURjQkCbPBnDNWDLgBFFMIcwsohJgdcs/Zztg+dzSEcWDQCmt4JOz2NMwi1hxSGkB3hcWGmtDrjJPL/f0mcIl7ysLCzBZAHXlcu4wXBgJsBwJc7JOfciwgAIy/UFZ2yEmrZdeNNPEoCRPcIQPCklsyzh2D7Dx73MxzFk8+l4KrgbVqaKcYpUgbF9GC1chmHbAbqobedKY/AstVVeCsbRegMJfyP/gDMZdfQjgmf93O5ojCJWygHDenHNEWX0bZINlNEgM8rCB8UyDB0pTRYVPrmXPaIHwdCiNF6lj0hh2gURg/e0IQCy3/KFtPA4gZCPeNUgqCnGhysxmoBlxsnBpQY6teX1AEx7sTCpETCqQwdsVvm0MUSPAYgQoKO4ddP2UMvXY1R5QxAGmIL1tUB2FNp9pF1j8IE+zK15DJigxBLnzqTpTgcu9dbGKNAEJBBxjKdaYdWXXY1B5YV5KepxVCcSX4CB1sXwMdRrGfXXw+iA94sE/xzV+TO7HYYookbyNTFyjiYApTTFjuM762KUQsyV6rUwbBrFsXTw06wePrguRggfMlsfrsVw8uZhMAdehldcu35dOohRhXAiluaNWYwhp6xnZHgTjNANbfPbRArP4tAJRKx+EOuej0kIsiOCKfjOBsPqr8AAbMZMesx7Jm9cjdHj0iqSMAgS34IwQ93bDGtJlDsJTkq5GHH6UUBlQM9OGT8JQnsJRieFosRDGKHf4xyBrsXAeg6LcslxRWzpJBvBsZBQh6o5I4tWzRwKZlYpwed0LV6GQcVRWJYF2FzcBKPvM1N0Oa9XC05GVEK6phBDYcZTFnYKa6QxYqqyVGEtWc1hSfMlIaOCKaQo0ZHhEV5hZNLrGYyR9OpIifuDAozpD9LGu1U6yBgr+/WVCNZBRQCOk4ZVJc4TKFJFTJeqwcIwNCsZJygYy8pAu8gQblRDB2FoPs6Gq02FvZd7+T8QZe/rH6zXkgelNRqNPLeX7vH/EoSCm10HJN7+9S9sRezCYnpnwzFRbqBtcytxYXKrCCInTsPM4uV+KHq4Mah3kqkbXvXw1gRLp2xtrPP9pHhYyi9bDe5Y4mYzNSt2FITB0CzyVBw7EMl5GgYpXVJ4N6rv4Z94oY52FQ/hvG+6HTY90nGgENPrcN50Thw4wZ2RXOINKnA5bnbchHKaA7uoXCUubn9ciOiowLscWxtwjxcqLrCTKE23woEFAO2VhO5XOJ7IOvmAruHrthTVuge7DLDlH/DWBq1RBcUwbftZTlPBXhAWOdTAkE5iCTqUpUb0A7hFqyS9LsukXs7BhVFMGMztM/26wB08bvON5mJY+Q9pl7eYxGF5x9kgSHA8vI0YXMgiGeCKkUOO6WGzguEkjs56+DQ2N3CwgWX5vRDWtrCAxe6Ig92V6nW8ErVW0xw3AazqCLSlb8FVapaUgtbIOJUQmOgdaq7Qsi7RmwnCKFBn1NzAFXVQxjSmgo/Edi9iCDZUtIOnz6aNMek9o1eY5p11DHjb02y40HdzjaFthw0CPQJc5BpRlGaDAabMbGzPGYn19o8wtE+iOWzaTrl0IZLU/1uGkXv1Fq2TWswaNjs16qKOOhWiwaj7V+GMp6kc9j14DzC42YzCLh0xnGrP1eM0f6b5Z2QINqnSqkNNp6UYdoNRlcOhrJDsKKFeIX4EYlQDGgxQuM4TZndXNt2PWrA/U30T7il6N8aIzbE9cPVvEgzDYAkGzZGTTcipQ9motJKwjVGINTDgGL02xW6mJf2ytxJD6YbSwChlyCuPm9VGVVn0Dms9bcSYMIoUVnOQo1dggKsDgA1e3jdjNZ9uBNySV76Rs3V8A/IBbOJKMLjW8BUY2A+wI6/qHIQWbdkbccixbxApSzAgF/G8I7FjpMdajQGbXdkf1Ekd1cF7tZfaIaMugmmSqEyYvHETDMeiFNI0abBdsgoDsp8Pu/LK+hFmWp+UqPIwk5Ds4VlR2Obz5OxUyzBMh9UBZm/Y5CKFbYmVGDEmVNak8MCCxGjxoixcD+tETutCzpJ+2KopV2EwBhUk6EEppGKHTZoiCBLa0q/EQJ03va0OtaqpZmC5EDIDjNyXuoIBDa0UrsMQ3HRHFN3gdIFZpb8ifZnDVt+THMIVEt6THGo23cgH1HeRokeZ3xH04wVhSFFhgA5rDHq42lw4hcThRKIK7mEyHwlZYVii6s3Zci440FJBOEiCtAndvB8mYd+skWzd26Qp4FAfqYh+PCLfiINkELR+komCJMGXY3oPnzRz53Boaphim1x+tgN2LYFcsGSps2sMRWVirxh2EA0h167xC/hWMDoMO4TerWy5CkNIb75GXyuFxSXb6PbIKYN47W7EEAKpZZH/AVrH9SkITlDFAAAAAElFTkSuQmCC" style={{width: "57px",marginLeft: "27px"}}/></div>
        <Dropdown overlay={menu} placement="bottomRight"><span style={{float:"right",marginRight: "20px",marginTop: "-62px"}}>
      
        <Avatar style={{ backgroundColor:"rgb(24, 144, 255)",float: "right",marginRight: "20px",marginTop: "20px"}} icon={<UserOutlined />} /><span style={{marginRight: "15px"}}>Welcome, shadab.k</span></span>
</Dropdown>
        </Header>
       
        <Content style={{ margin: '0 16px' }}>
          <Route exact path="/" component={Dashboard} />
        </Content>
        <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
      </Layout>
    </Layout>
    </Router>
    );
  }
}


export default App;
