import React,{Component} from 'react';
import logo from './logo.svg';
import { GooglePlusOutlined } from '@ant-design/icons';
import './App.css';
import { Layout,Card } from 'antd';
import { Row, Col,Form, Input, Button, Checkbox,Tabs } from 'antd';
const { Header, Footer, Sider, Content } = Layout;

const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const { TabPane } = Tabs;
const tailLayout = {
  wrapperCol: { offset: 8, span: 16 },
};
class App extends Component {
  constructor(props) {
		super(props);
    this.state = {
      collapsed: false,
    };
  }
  callback(key) {
    console.log(key);
  }
  render()
  {
  return (
    <div className="App">
    
 
    <Layout className="site-layout" id="bg" style={{backgroundSize: "cover",backgroundPosition: "center"}}>
    <div className="site-card-border-less-wrapper" style={{height: "1000px"}}>
    <Card title="" bordered={false} style={{ width: "21%",float:"right",marginRight: "2%",marginTop: "13%",boxShadow: "5px 4px 5px #100f0f" }}>

    <Tabs defaultActiveKey="1" onChange={this.callback}>
    <TabPane tab="Login" key="1">
    <div style={{marginTop: "5%"}}>
<Form
{...layout}
name="basic"
initialValues={{ remember: true }}

>
<Form.Item
  label="Username"
  name="username"
  rules={[{ required: true, message: 'Please input your username!' }]}
 
>
  <Input  />
</Form.Item>

<Form.Item
  label="Password"
  name="password"
  rules={[{ required: true, message: 'Please input your password!' }]}
  
>
  <Input.Password />
</Form.Item>



<Form.Item {...tailLayout}>
  <div style={{marginLeft: "-51%"}}>
  <Row>
<Col span={12}>
  <Button type="primary" htmlType="submit">
    Submit
  </Button></Col>
  <Col span={12}>
  <Button type="danger" htmlType="submit" icon={<GooglePlusOutlined />} style={{marginLeft:"-16%"}}>
    Google Signin
  </Button></Col>
  </Row>
  </div>
</Form.Item>
</Form>

</div>
    </TabPane>
    <TabPane tab="Signup" key="2">
      Content of Tab Pane 2
    </TabPane>
   
  </Tabs>
  </Card>
    </div>
    </Layout>

    
  </div>
 
); 
}
}

export default App;
